import { Link, useLocation } from "wouter";
import { LayoutDashboard, Package, ShoppingCart, Users, CreditCard, Menu, X, PieChart, Crown } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const navItems = [
  { href: "/", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/products", icon: Package, label: "Produtos" },
  { href: "/pos", icon: ShoppingCart, label: "Vender" },
  { href: "/customers", icon: Users, label: "Clientes" },
  { href: "/debts", icon: CreditCard, label: "Fiado & Dívidas" },
  { href: "/reports", icon: PieChart, label: "Relatórios Pro" },
];

export function Sidebar() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Mobile Toggle */}
      <div className="md:hidden fixed top-0 left-0 right-0 h-16 bg-sidebar flex items-center px-4 z-50 border-b border-sidebar-border">
        <Button variant="ghost" size="icon" onClick={() => setIsOpen(!isOpen)} className="text-sidebar-foreground">
          {isOpen ? <X /> : <Menu />}
        </Button>
        <div className="ml-4 flex items-center gap-2 font-bold text-red-600">
          <Crown className="w-5 h-5 fill-red-600" />
          <span className="uppercase tracking-tighter italic">REI DAS VENDAS</span>
        </div>
      </div>

      {/* Sidebar Container */}
      <aside 
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-64 bg-sidebar text-sidebar-foreground transform transition-transform duration-200 ease-in-out md:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full",
          "md:static md:block"
        )}
      >
        <div className="h-full flex flex-col">
          <div className="p-8 border-b border-sidebar-border hidden md:block">
            <div className="flex items-center gap-2 font-black text-2xl text-red-600 italic">
              <Crown className="w-8 h-8 fill-red-600" />
              <span className="tracking-tighter">REI DAS VENDAS</span>
            </div>
            <p className="text-[10px] text-sidebar-foreground/40 mt-1 uppercase tracking-[0.2em] font-bold">Premium Management</p>
          </div>

          <nav className="flex-1 py-6 px-3 space-y-1">
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <Link key={item.href} href={item.href}>
                  <div 
                    onClick={() => setIsOpen(false)}
                    className={cn(
                      "flex items-center gap-3 px-4 py-3 rounded-md transition-all duration-200 cursor-pointer group",
                      isActive 
                        ? "bg-sidebar-accent text-sidebar-accent-foreground font-bold shadow-md" 
                        : "text-sidebar-foreground/70 hover:bg-sidebar-accent/30 hover:text-sidebar-foreground"
                    )}
                  >
                    <item.icon className={cn("w-5 h-5 transition-colors", isActive ? "text-red-500" : "text-sidebar-foreground/40 group-hover:text-red-400")} />
                    <span className="text-sm uppercase tracking-wide">{item.label}</span>
                    {isActive && <div className="ml-auto w-1 h-4 rounded-full bg-red-600 shadow-[0_0_8px_rgba(220,38,38,0.6)]" />}
                  </div>
                </Link>
              );
            })}
          </nav>

          <div className="p-4 border-t border-sidebar-border">
            <div className="bg-red-600/10 rounded-xl p-4 border border-red-600/20">
              <p className="text-[10px] text-red-500 font-bold uppercase tracking-wider mb-1">Status do Caixa</p>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <p className="text-sm font-bold truncate">Operação Ativa</p>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-30 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}
    </>
  );
}
