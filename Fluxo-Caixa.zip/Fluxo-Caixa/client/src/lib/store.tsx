import React, { createContext, useContext, useState, ReactNode } from 'react';

// Types
export interface Product {
  id: number;
  nome: string;
  categoria: string;
  preco: number;
  custo: number;
  estoque: number;
}

export interface Client {
  id: number;
  nome: string;
  telefone: string;
  divida: number;
}

export interface Debt {
  id: number;
  clientId: number;
  clienteNome: string;
  valor: number;
  pago: number;
  vencimento: string;
  juros: number;
}

export interface Sale {
  id: number;
  date: string;
  total: number;
  items: { productId: number; nome: string; quantity: number; price: number; cost: number }[];
  type: 'money' | 'credit';
  clientId?: number;
}

interface StoreContextType {
  products: Product[];
  clients: Client[];
  debts: Debt[];
  sales: Sale[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: number, product: Partial<Product>) => void;
  deleteProduct: (id: number) => void;
  addClient: (client: Omit<Client, 'id'>) => void;
  addDebt: (debt: Omit<Debt, 'id'>) => void;
  addSale: (sale: Omit<Sale, 'id'>) => void;
  payDebt: (debtId: number, amount: number) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider = ({ children }: { children: ReactNode }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [debts, setDebts] = useState<Debt[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);

  const addProduct = (product: Omit<Product, 'id'>) => {
    setProducts(prev => [...prev, { ...product, id: Date.now() }]);
  };

  const updateProduct = (id: number, product: Partial<Product>) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, ...product } : p));
  };

  const deleteProduct = (id: number) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const addClient = (client: Omit<Client, 'id'>) => {
    setClients(prev => [...prev, { ...client, id: Date.now() }]);
  };

  const addDebt = (debt: Omit<Debt, 'id'>) => {
    setDebts(prev => [...prev, { ...debt, id: Date.now() }]);
    setClients(prev => prev.map(c => 
      c.id === debt.clientId 
        ? { ...c, divida: c.divida + (debt.valor - debt.pago) }
        : c
    ));
  };

  const payDebt = (debtId: number, amount: number) => {
    setDebts(prev => prev.map(d => {
      if (d.id === debtId) {
        const newPaid = d.pago + amount;
        setClients(prevClients => prevClients.map(c => {
           if (c.id === d.clientId) {
             return { ...c, divida: Math.max(0, c.divida - amount) };
           }
           return c;
        }));
        return { ...d, pago: newPaid };
      }
      return d;
    }));
  };

  const addSale = (sale: Omit<Sale, 'id'>) => {
    setSales(prev => [...prev, { ...sale, id: Date.now() }]);
    sale.items.forEach(item => {
      setProducts(prev => prev.map(p => 
        p.id === item.productId 
          ? { ...p, estoque: Math.max(0, p.estoque - item.quantity) }
          : p
      ));
    });
  };

  return (
    <StoreContext.Provider value={{ 
      products, clients, debts, sales, 
      addProduct, updateProduct, deleteProduct, 
      addClient, addDebt, addSale, payDebt 
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
