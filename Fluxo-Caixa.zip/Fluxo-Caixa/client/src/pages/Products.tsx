import { useState } from "react";
import { useStore, Product } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, Trash2, MoreHorizontal } from "lucide-react";
import { useForm } from "react-hook-form";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

export default function Products() {
  const { products, addProduct, deleteProduct } = useStore();
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const { register, handleSubmit, reset } = useForm<Omit<Product, 'id'>>();

  const onSubmit = (data: Omit<Product, 'id'>) => {
    const payload = {
      ...data,
      preco: Number(data.preco),
      custo: Number(data.custo),
      estoque: Number(data.estoque)
    };
    addProduct(payload);
    reset();
    setIsOpen(false);
  };

  const filteredProducts = products.filter(p => 
    p.nome.toLowerCase().includes(search.toLowerCase()) || 
    p.categoria.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Produtos</h1>
          <p className="text-sm md:text-base text-muted-foreground">Gerencie seu estoque, custos e preços.</p>
        </div>
        
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 w-full sm:w-auto">
              <Plus size={18} /> Novo Produto
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Adicionar Produto</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="nome">Nome do Produto</Label>
                <Input id="nome" {...register("nome", { required: true })} placeholder="Ex: Camiseta Nike" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="categoria">Categoria</Label>
                <Input id="categoria" {...register("categoria", { required: true })} placeholder="Ex: Roupas" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="custo">Custo (R$)</Label>
                  <Input id="custo" type="number" step="0.01" {...register("custo", { required: true })} placeholder="0.00" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="preco">Venda (R$)</Label>
                  <Input id="preco" type="number" step="0.01" {...register("preco", { required: true })} placeholder="0.00" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="estoque">Estoque Inicial</Label>
                <Input id="estoque" type="number" {...register("estoque", { required: true })} placeholder="0" />
              </div>

              <Button type="submit" className="w-full">Salvar Produto</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex items-center">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Buscar por nome ou categoria..."
            className="pl-8"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Desktop Table View */}
      <div className="hidden md:block rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Produto</TableHead>
              <TableHead>Categoria</TableHead>
              <TableHead>Custo</TableHead>
              <TableHead>Preço</TableHead>
              <TableHead>Lucro Est.</TableHead>
              <TableHead>Estoque</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredProducts.map((produto) => {
              const lucro = produto.preco - produto.custo;
              const margem = (lucro / produto.preco) * 100;
              return (
                <TableRow key={produto.id}>
                  <TableCell className="font-medium">{produto.nome}</TableCell>
                  <TableCell>
                    <Badge variant="secondary">{produto.categoria}</Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">R$ {produto.custo.toFixed(2)}</TableCell>
                  <TableCell>R$ {produto.preco.toFixed(2)}</TableCell>
                  <TableCell className="text-green-600">
                    R$ {lucro.toFixed(2)} <span className="text-xs text-muted-foreground">({margem.toFixed(0)}%)</span>
                  </TableCell>
                  <TableCell>
                    <span className={produto.estoque < 10 ? "text-destructive font-bold" : "text-green-600 font-bold"}>
                      {produto.estoque} un
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => deleteProduct(produto.id)}>
                      <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {/* Mobile Card View */}
      <div className="grid grid-cols-1 gap-4 md:hidden">
        {filteredProducts.map((produto) => {
          const lucro = produto.preco - produto.custo;
          return (
            <Card key={produto.id} className="hover-elevate">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 p-4 pb-2">
                <div>
                  <CardTitle className="text-base">{produto.nome}</CardTitle>
                  <Badge variant="secondary" className="mt-1">{produto.categoria}</Badge>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem className="text-destructive" onClick={() => deleteProduct(produto.id)}>
                      Excluir
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </CardHeader>
              <CardContent className="p-4 pt-2 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Preço de Venda:</span>
                  <span className="font-bold">R$ {produto.preco.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Estoque:</span>
                  <span className={produto.estoque < 10 ? "text-destructive font-bold" : "text-green-600 font-bold"}>
                    {produto.estoque} un
                  </span>
                </div>
                <div className="flex justify-between text-sm pt-2 border-t">
                  <span className="text-muted-foreground">Lucro p/ un:</span>
                  <span className="text-green-600 font-semibold">R$ {lucro.toFixed(2)}</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-12 text-muted-foreground bg-card rounded-lg border border-dashed">
          Nenhum produto encontrado.
        </div>
      )}
    </div>
  );
}
