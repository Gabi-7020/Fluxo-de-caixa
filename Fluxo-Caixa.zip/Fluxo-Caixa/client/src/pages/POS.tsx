import { useState } from "react";
import { useStore, Product } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, ShoppingCart, Trash2, CreditCard, DollarSign, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";

export default function POS() {
  const { products, clients, addSale, addDebt } = useStore();
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<Product[]>([]);
  const [selectedClient, setSelectedClient] = useState<string>("");
  const [isFiadoOpen, setIsFiadoOpen] = useState(false);
  const [isCartOpenMobile, setIsCartOpenMobile] = useState(false);
  const { toast } = useToast();

  const addToCart = (product: Product) => {
    if (product.estoque <= 0) {
      toast({ title: "Estoque indisponível", variant: "destructive" });
      return;
    }
    setCart([...cart, product]);
    toast({ title: "Adicionado ao carrinho", description: product.nome, duration: 1000 });
  };

  const removeFromCart = (index: number) => {
    setCart(cart.filter((_, i) => i !== index));
  };

  const total = cart.reduce((acc, item) => acc + item.preco, 0);

  const handleSale = (type: 'money' | 'credit') => {
    if (cart.length === 0) return;

    if (type === 'credit' && !selectedClient) {
      toast({ title: "Selecione um cliente", variant: "destructive" });
      return;
    }

    const saleItems = cart.map(p => ({
      productId: p.id,
      nome: p.nome,
      quantity: 1,
      price: p.preco,
      cost: p.custo
    }));

    addSale({
      total,
      items: saleItems,
      type,
      clientId: selectedClient ? Number(selectedClient) : undefined,
      date: new Date().toISOString()
    });

    if (type === 'credit') {
      const client = clients.find(c => c.id === Number(selectedClient));
      addDebt({
        clientId: Number(selectedClient),
        clienteNome: client?.nome || 'Desconhecido',
        valor: total,
        pago: 0,
        vencimento: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        juros: 0
      });
      setIsFiadoOpen(false);
    }

    toast({ 
      title: "Venda realizada com sucesso!", 
      description: `Total: R$ ${total.toFixed(2)}` 
    });
    
    setCart([]);
    setSelectedClient("");
    setIsCartOpenMobile(false);
  };

  const filteredProducts = products.filter(p => 
    p.nome.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex flex-col lg:grid lg:grid-cols-2 gap-6 h-full min-h-0">
      {/* Product Selection */}
      <Card className="flex flex-col h-full min-h-[400px] lg:min-h-0 hover-elevate overflow-hidden">
        <CardHeader className="p-4">
          <CardTitle className="text-xl">Catálogo</CardTitle>
          <div className="relative mt-2">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Buscar produto..."
              className="pl-8"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto space-y-2 p-2 sm:p-4 scrollbar-thin">
          {filteredProducts.map(produto => (
            <div 
              key={produto.id} 
              className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors active:bg-muted"
            >
              <div className="min-w-0 flex-1 pr-2">
                <p className="font-semibold truncate">{produto.nome}</p>
                <p className="text-sm text-muted-foreground">R$ {produto.preco.toFixed(2)} • Est: {produto.estoque}</p>
              </div>
              <Button size="sm" onClick={() => addToCart(produto)} disabled={produto.estoque <= 0}>
                <Plus size={16} />
              </Button>
            </div>
          ))}
        </CardContent>
        {/* Mobile Cart Trigger */}
        <div className="lg:hidden p-4 border-t bg-muted/20">
          <Button 
            className="w-full justify-between h-12 text-lg" 
            onClick={() => setIsCartOpenMobile(true)}
            disabled={cart.length === 0}
          >
            <div className="flex items-center gap-2">
              <ShoppingCart size={20} /> Ver Carrinho ({cart.length})
            </div>
            <span className="font-bold font-mono">R$ {total.toFixed(2)}</span>
          </Button>
        </div>
      </Card>

      {/* Cart - Desktop Sidebar / Mobile Fullscreen Overlay */}
      <div className={cn(
        "fixed inset-0 z-50 bg-background lg:relative lg:inset-auto lg:z-0 lg:flex lg:flex-col transition-transform duration-300 transform",
        isCartOpenMobile ? "translate-y-0" : "translate-y-full lg:translate-y-0"
      )}>
        <Card className="flex flex-col h-full border-primary/20 hover-elevate rounded-none lg:rounded-lg">
          <CardHeader className="bg-primary/5 border-b border-primary/10 flex flex-row items-center justify-between p-4">
            <CardTitle className="flex items-center gap-2 text-xl">
              <ShoppingCart className="w-5 h-5 text-primary" />
              Carrinho
            </CardTitle>
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setIsCartOpenMobile(false)}>
              <X />
            </Button>
          </CardHeader>
          <CardContent className="flex-1 overflow-y-auto p-4 space-y-3">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-muted-foreground opacity-50 py-12">
                <ShoppingCart size={48} className="mb-4" />
                <p>Carrinho vazio</p>
              </div>
            ) : (
              cart.map((item, index) => (
                <div key={index} className="flex justify-between items-center p-3 bg-card border rounded-lg shadow-sm animate-in slide-in-from-right-2">
                  <span className="font-medium truncate pr-2">{item.nome}</span>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="font-mono text-sm">R$ {item.preco.toFixed(2)}</span>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => removeFromCart(index)}>
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </CardContent>
          <CardFooter className="flex-col gap-4 bg-muted/20 border-t p-4 md:p-6">
            <div className="flex justify-between w-full items-end mb-2">
              <span className="text-muted-foreground">Total:</span>
              <span className="text-2xl md:text-3xl font-bold text-primary font-mono">R$ {total.toFixed(2)}</span>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full">
              <Button 
                className="w-full gap-2 h-12 text-base md:text-lg" 
                onClick={() => handleSale('money')}
                disabled={cart.length === 0}
              >
                <DollarSign size={20} /> À Vista
              </Button>

              <Dialog open={isFiadoOpen} onOpenChange={setIsFiadoOpen}>
                <DialogTrigger asChild>
                   <Button variant="secondary" className="w-full gap-2 h-12 text-base md:text-lg" disabled={cart.length === 0}>
                     <CreditCard size={20} /> Fiado
                   </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[400px]">
                  <DialogHeader>
                    <DialogTitle>Venda Fiado</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                     <div className="space-y-2">
                       <label className="text-sm font-medium">Selecione o Cliente</label>
                       <Select onValueChange={setSelectedClient}>
                          <SelectTrigger>
                            <SelectValue placeholder="Buscar cliente..." />
                          </SelectTrigger>
                          <SelectContent>
                            {clients.map(c => (
                              <SelectItem key={c.id} value={c.id.toString()}>{c.nome}</SelectItem>
                            ))}
                          </SelectContent>
                       </Select>
                     </div>
                     <div className="p-4 bg-muted rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1 uppercase tracking-wider font-bold">Total da Dívida</p>
                        <p className="text-2xl font-bold text-primary font-mono">R$ {total.toFixed(2)}</p>
                     </div>
                     <Button className="w-full h-12" onClick={() => handleSale('credit')}>Confirmar Venda</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
