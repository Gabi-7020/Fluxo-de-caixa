import { useStore } from "@/lib/store";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DollarSign } from "lucide-react";

export default function Debts() {
  const { debts, payDebt } = useStore();
  const [paymentAmount, setPaymentAmount] = useState<string>("");
  const [selectedDebt, setSelectedDebt] = useState<number | null>(null);
  const [isPayOpen, setIsPayOpen] = useState(false);

  const handlePayment = () => {
    if (selectedDebt && paymentAmount) {
      payDebt(selectedDebt, Number(paymentAmount));
      setIsPayOpen(false);
      setPaymentAmount("");
      setSelectedDebt(null);
    }
  };

  // Filter only unpaid or partially paid debts
  const activeDebts = debts.filter(d => d.valor > d.pago);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Controle de Fiado</h1>
        <p className="text-muted-foreground">Gerencie as dívidas e recebimentos.</p>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Cliente</TableHead>
              <TableHead>Valor Total</TableHead>
              <TableHead>Já Pago</TableHead>
              <TableHead>Restante</TableHead>
              <TableHead>Vencimento</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {activeDebts.map((debt) => {
              const restante = debt.valor - debt.pago;
              return (
                <TableRow key={debt.id}>
                  <TableCell className="font-medium">{debt.clienteNome}</TableCell>
                  <TableCell>R$ {debt.valor.toFixed(2)}</TableCell>
                  <TableCell className="text-green-600">R$ {debt.pago.toFixed(2)}</TableCell>
                  <TableCell className="text-destructive font-bold">R$ {restante.toFixed(2)}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{new Date(debt.vencimento).toLocaleDateString('pt-BR')}</Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Dialog open={isPayOpen && selectedDebt === debt.id} onOpenChange={(open) => {
                      setIsPayOpen(open);
                      if (!open) setSelectedDebt(null);
                    }}>
                      <DialogTrigger asChild>
                        <Button size="sm" variant="outline" onClick={() => setSelectedDebt(debt.id)}>
                          <DollarSign className="w-4 h-4 mr-1" /> Receber
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Registrar Pagamento</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <p>Dívida de <strong>{debt.clienteNome}</strong></p>
                          <p>Valor restante: <span className="text-destructive font-bold">R$ {restante.toFixed(2)}</span></p>
                          
                          <div className="space-y-2">
                            <label className="text-sm">Valor a pagar agora:</label>
                            <Input 
                              type="number" 
                              value={paymentAmount} 
                              onChange={(e) => setPaymentAmount(e.target.value)}
                              placeholder="0.00"
                              max={restante}
                            />
                          </div>
                          <Button className="w-full" onClick={handlePayment}>Confirmar Pagamento</Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </TableCell>
                </TableRow>
              );
            })}
            {activeDebts.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center h-24 text-muted-foreground">
                  Nenhuma dívida pendente. Parabéns!
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
