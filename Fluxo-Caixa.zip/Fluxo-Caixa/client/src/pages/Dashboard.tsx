import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useStore } from "@/lib/store";
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { DollarSign, Package, AlertCircle, TrendingUp, Users, ArrowUpRight, ArrowDownRight, CreditCard } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";

export default function Dashboard() {
  const { sales, products, debts, clients } = useStore();

  const totalVendas = sales.reduce((acc, s) => acc + s.total, 0);
  const totalDividas = debts.reduce((acc, d) => acc + (d.valor - d.pago), 0);
  const totalProdutos = products.length;
  const totalClientes = clients.length;

  // Prepare Chart Data
  const salesByDate = sales.reduce((acc: any, sale) => {
    const date = format(new Date(sale.date), 'dd/MM', { locale: ptBR });
    acc[date] = (acc[date] || 0) + sale.total;
    return acc;
  }, {});

  const chartData = Object.keys(salesByDate).map(date => ({
    name: date,
    total: salesByDate[date]
  }));

  const displayChartData = chartData.length > 0 ? chartData : [
    { name: '20/05', total: 1200 },
    { name: '21/05', total: 2100 },
    { name: '22/05', total: 800 },
    { name: '23/05', total: 1600 },
    { name: '24/05', total: 2400 },
    { name: '25/05', total: 1900 },
    { name: '26/05', total: 3100 },
  ];

  const recentSales = sales.slice(-5).reverse();

  return (
    <div className="space-y-6 md:space-y-8 pb-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-black tracking-tighter text-foreground uppercase italic">Visão Geral</h1>
          <p className="text-muted-foreground font-medium">Controle de faturamento e operações Rei das Vendas.</p>
        </div>
        <div className="flex items-center gap-2 bg-card border rounded-full px-4 py-2 shadow-sm">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-xs font-bold uppercase tracking-wider">{format(new Date(), "dd 'de' MMMM", { locale: ptBR })}</span>
        </div>
      </div>

      {/* Primary Stats Grid */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="hover-elevate overflow-hidden border-none bg-gradient-to-br from-red-600 to-red-700 text-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-bold uppercase tracking-widest opacity-80">Receita Total</CardTitle>
            <DollarSign className="h-4 w-4 opacity-80" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-black">R$ {totalVendas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            <div className="flex items-center mt-1 text-xs font-bold bg-white/20 w-fit px-2 py-0.5 rounded-full">
              <ArrowUpRight className="w-3 h-3 mr-1" /> +12.5%
            </div>
          </CardContent>
        </Card>
        
        <Card className="hover-elevate border-l-4 border-l-blue-500 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Estoque Ativo</CardTitle>
            <Package className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-black">{totalProdutos}</div>
            <p className="text-[10px] text-muted-foreground mt-1 font-bold">PRODUTOS CADASTRADOS</p>
          </CardContent>
        </Card>
        
        <Card className="hover-elevate border-l-4 border-l-amber-500 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Clientes</CardTitle>
            <Users className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-black">{totalClientes}</div>
            <p className="text-[10px] text-muted-foreground mt-1 font-bold">BASE DE DADOS</p>
          </CardContent>
        </Card>

        <Card className="hover-elevate border-l-4 border-l-red-500 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Fiado Pendente</CardTitle>
            <AlertCircle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-black text-red-600">R$ {totalDividas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
            <p className="text-[10px] text-muted-foreground mt-1 font-bold">VALORES A RECEBER</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 grid-cols-1 lg:grid-cols-7">
        {/* Sales Chart */}
        <Card className="lg:col-span-4 hover-elevate border-none shadow-lg bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-xl font-black uppercase tracking-tighter italic">Fluxo de Vendas</CardTitle>
            <CardDescription>Performance de faturamento nos últimos 7 dias.</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[300px] md:h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={displayChartData}>
                  <defs>
                    <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="rgb(220, 38, 38)" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="rgb(220, 38, 38)" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(0,0,0,0.05)" />
                  <XAxis 
                    dataKey="name" 
                    stroke="#888888" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false}
                    dy={10}
                  />
                  <YAxis 
                    stroke="#888888" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                    tickFormatter={(value) => `R$${value}`} 
                  />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)', fontWeight: 'bold' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="total" 
                    stroke="rgb(220, 38, 38)" 
                    strokeWidth={4}
                    fillOpacity={1} 
                    fill="url(#colorTotal)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="lg:col-span-3 hover-elevate border-none shadow-lg bg-card/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-xl font-black uppercase tracking-tighter italic">Vendas Recentes</CardTitle>
            <CardDescription>Últimas movimentações do PDV.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {recentSales.map((sale) => (
                <div key={sale.id} className="flex items-center gap-4">
                  <div className={cn(
                    "h-10 w-10 rounded-full flex items-center justify-center shrink-0",
                    sale.type === 'money' ? "bg-green-100 text-green-600" : "bg-amber-100 text-amber-600"
                  )}>
                    {sale.type === 'money' ? <DollarSign size={20} /> : <CreditCard size={20} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold truncate">Venda #{sale.id.toString().slice(-4)}</p>
                    <p className="text-xs text-muted-foreground font-medium">
                      {format(new Date(sale.date), "HH:mm '•' dd/MM")}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-black">R$ {sale.total.toFixed(2)}</p>
                    <p className={cn(
                      "text-[10px] font-bold uppercase",
                      sale.type === 'money' ? "text-green-600" : "text-amber-600"
                    )}>
                      {sale.type === 'money' ? 'À Vista' : 'Fiado'}
                    </p>
                  </div>
                </div>
              ))}
              {recentSales.length === 0 && (
                <div className="text-center py-10 text-muted-foreground">
                  <p className="text-sm font-medium">Nenhuma atividade recente.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
