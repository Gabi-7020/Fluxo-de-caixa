import { useStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Target } from "lucide-react";

export default function Reports() {
  const { sales, products } = useStore();

  let totalRevenue = 0;
  let totalCost = 0;
  
  sales.forEach(sale => {
    totalRevenue += sale.total;
    sale.items.forEach(item => {
      const product = products.find(p => p.id === item.productId);
      const cost = item.cost || (product ? product.custo : 0);
      totalCost += cost * item.quantity;
    });
  });

  const netProfit = totalRevenue - totalCost;
  const margin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

  const productPerformance = products.map(product => {
    let soldQuantity = 0;
    let revenue = 0;
    let cost = 0;

    sales.forEach(sale => {
      const item = sale.items.find(i => i.productId === product.id);
      if (item) {
        soldQuantity += item.quantity;
        revenue += item.quantity * item.price;
        cost += item.quantity * (item.cost || product.custo);
      }
    });

    return {
      name: product.nome,
      quantity: soldQuantity,
      revenue,
      profit: revenue - cost,
      margin: revenue > 0 ? ((revenue - cost) / revenue) * 100 : 0
    };
  }).filter(p => p.quantity > 0).sort((a, b) => b.profit - a.profit);

  const topSelling = productPerformance.slice(0, 5);

  const chartData = sales.map(sale => {
    let saleCost = 0;
    sale.items.forEach(item => {
       const product = products.find(p => p.id === item.productId);
       saleCost += (item.cost || product?.custo || 0) * item.quantity;
    });
    
    return {
      date: new Date(sale.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
      vendas: sale.total,
      lucro: sale.total - saleCost
    };
  });

  return (
    <div className="space-y-6 md:space-y-8 pb-8">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Relatórios Pro</h1>
        <p className="text-sm md:text-base text-muted-foreground">Análise de lucros e performance.</p>
      </div>

      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="hover-elevate bg-green-50/30 dark:bg-green-950/10 border-green-100 dark:border-green-900/50">
          <CardHeader className="p-4 pb-2">
            <CardTitle className="text-sm font-medium text-green-700 dark:text-green-400">Receita</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <div className="text-xl md:text-2xl font-bold text-green-700 dark:text-green-400">R$ {totalRevenue.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card className="hover-elevate bg-red-50/30 dark:bg-red-950/10 border-red-100 dark:border-red-900/50">
          <CardHeader className="p-4 pb-2">
            <CardTitle className="text-sm font-medium text-red-700 dark:text-red-400">Custos</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <div className="text-xl md:text-2xl font-bold text-red-700 dark:text-red-400">R$ {totalCost.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card className="hover-elevate bg-blue-50/30 dark:bg-blue-950/10 border-blue-100 dark:border-blue-900/50">
          <CardHeader className="p-4 pb-2">
            <CardTitle className="text-sm font-medium text-blue-700 dark:text-blue-400">Lucro</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <div className="text-xl md:text-2xl font-bold text-blue-700 dark:text-blue-400">R$ {netProfit.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader className="p-4 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Margem</CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0">
            <div className="text-xl md:text-2xl font-bold">{margin.toFixed(1)}%</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 grid-cols-1 lg:grid-cols-7">
        <Card className="lg:col-span-4 hover-elevate">
          <CardHeader>
            <CardTitle className="text-lg">Vendas vs Lucro</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <XAxis dataKey="date" stroke="#888888" fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke="#888888" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(value) => `R$${value}`} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Legend />
                  <Bar dataKey="vendas" name="Venda" fill="#10B981" radius={[2, 2, 0, 0]} />
                  <Bar dataKey="lucro" name="Lucro" fill="#3B82F6" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-3 hover-elevate">
          <CardHeader>
            <CardTitle className="text-lg">Top Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-5">
              {topSelling.map((product, index) => (
                <div key={index} className="flex items-center">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary font-bold text-xs">
                    {index + 1}
                  </div>
                  <div className="ml-3 space-y-1 flex-1 min-w-0">
                    <p className="text-sm font-medium leading-none truncate">{product.name}</p>
                    <p className="text-xs text-muted-foreground">{product.quantity} un</p>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-sm font-bold text-green-600">R$ {product.profit.toFixed(0)}</div>
                    <div className="text-[10px] text-muted-foreground">{product.margin.toFixed(0)}%</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
