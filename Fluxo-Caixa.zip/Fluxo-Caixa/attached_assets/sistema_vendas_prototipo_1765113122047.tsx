import React, { useState } from 'react';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Search, Plus, ShoppingCart, Users, CreditCard, Package, TrendingUp, DollarSign, AlertCircle } from 'lucide-react';

const SistemaVendas = () => {
  const [telaAtiva, setTelaAtiva] = useState('dashboard');
  const [busca, setBusca] = useState('');
  const [carrinho, setCarrinho] = useState([]);
  const [modalAberto, setModalAberto] = useState(null);

  // Dados mockados
  const [produtos, setProdutos] = useState([
    { id: 1, nome: 'Camiseta Nike', categoria: 'Roupas', preco: 89.90, estoque: 25 },
    { id: 2, nome: 'iPhone 13', categoria: 'Telefones', preco: 3500.00, estoque: 5 },
    { id: 3, nome: 'Perfume Dior', categoria: 'Perfumes', preco: 450.00, estoque: 12 },
    { id: 4, nome: 'Tênis Adidas', categoria: 'Sapatos', preco: 299.90, estoque: 18 },
    { id: 5, nome: 'Arma Gel X1', categoria: 'Armas de Gel', preco: 120.00, estoque: 8 },
  ]);

  const [clientes, setClientes] = useState([
    { id: 1, nome: 'João Silva', telefone: '(24) 98765-4321', divida: 450.00 },
    { id: 2, nome: 'Maria Santos', telefone: '(24) 99876-5432', divida: 0 },
    { id: 3, nome: 'Pedro Costa', telefone: '(24) 97654-3210', divida: 280.00 },
  ]);

  const [dividas, setDividas] = useState([
    { id: 1, cliente: 'João Silva', valor: 450.00, pago: 150.00, vencimento: '2024-12-05', juros: 5 },
    { id: 2, cliente: 'Pedro Costa', valor: 280.00, pago: 80.00, vencimento: '2024-12-10', juros: 3 },
  ]);

  const vendasMes = [
    { mes: 'Jan', valor: 2500 },
    { mes: 'Fev', valor: 3200 },
    { mes: 'Mar', valor: 2800 },
    { mes: 'Abr', valor: 4100 },
    { mes: 'Mai', valor: 3800 },
  ];

  const vendasCategoria = [
    { nome: 'Roupas', valor: 5200, cor: '#4CAF50' },
    { nome: 'Telefones', valor: 8500, cor: '#2196F3' },
    { nome: 'Perfumes', valor: 3200, cor: '#9C27B0' },
    { nome: 'Sapatos', valor: 4100, cor: '#FF9800' },
    { nome: 'Armas Gel', valor: 1800, cor: '#F44336' },
  ];

  const produtosFiltrados = produtos.filter(p => 
    p.nome.toLowerCase().includes(busca.toLowerCase()) ||
    p.categoria.toLowerCase().includes(busca.toLowerCase())
  );

  const totalVendasHoje = 1250.00;
  const totalDividas = dividas.reduce((acc, d) => acc + (d.valor - d.pago), 0);

  // Menu Lateral
  const MenuLateral = () => (
    <div className="w-64 bg-gray-900 text-white h-screen flex flex-col">
      <div className="p-6 text-center border-b border-gray-700">
        <ShoppingCart className="inline-block mb-2" size={32} />
        <h1 className="text-2xl font-bold">VENDAS</h1>
      </div>
      
      <nav className="flex-1 py-4">
        {[
          { id: 'dashboard', icon: TrendingUp, label: 'Dashboard' },
          { id: 'produtos', icon: Package, label: 'Produtos' },
          { id: 'vender', icon: ShoppingCart, label: 'Vender' },
          { id: 'clientes', icon: Users, label: 'Clientes' },
          { id: 'dividas', icon: CreditCard, label: 'Dívidas' },
        ].map(item => (
          <button
            key={item.id}
            onClick={() => setTelaAtiva(item.id)}
            className={`w-full flex items-center gap-3 px-6 py-3 hover:bg-gray-800 transition ${
              telaAtiva === item.id ? 'bg-gray-800 border-l-4 border-green-500' : ''
            }`}
          >
            <item.icon size={20} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );

  // Cards de estatísticas
  const Card = ({ titulo, valor, icon: Icon, cor }) => (
    <div className="bg-white rounded-lg shadow p-6 flex items-center gap-4">
      <div className={`p-4 rounded-full ${cor}`}>
        <Icon size={24} className="text-white" />
      </div>
      <div>
        <p className="text-gray-600 text-sm">{titulo}</p>
        <p className="text-2xl font-bold text-gray-900">{valor}</p>
      </div>
    </div>
  );

  // Dashboard
  const Dashboard = () => (
    <div className="p-8">
      <h2 className="text-3xl font-bold mb-6 text-gray-900">📊 Dashboard</h2>
      
      <div className="grid grid-cols-3 gap-6 mb-8">
        <Card titulo="Vendas Hoje" valor={`R$ ${totalVendasHoje.toFixed(2)}`} icon={DollarSign} cor="bg-green-500" />
        <Card titulo="Total Produtos" valor={produtos.length} icon={Package} cor="bg-blue-500" />
        <Card titulo="Dívidas Pendentes" valor={`R$ ${totalDividas.toFixed(2)}`} icon={AlertCircle} cor="bg-red-500" />
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-xl font-semibold mb-4">Vendas por Mês</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={vendasMes}>
              <XAxis dataKey="mes" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="valor" fill="#4CAF50" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-xl font-semibold mb-4">Vendas por Categoria</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={vendasCategoria} dataKey="valor" nameKey="nome" cx="50%" cy="50%" outerRadius={80}>
                {vendasCategoria.map((entry, index) => (
                  <Cell key={index} fill={entry.cor} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );

  // Tela de Produtos
  const Produtos = () => (
    <div className="p-8">
      <h2 className="text-3xl font-bold mb-6 text-gray-900">📦 Gestão de Produtos</h2>
      
      <div className="flex gap-4 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Buscar produto por nome ou categoria..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          />
        </div>
        <button 
          onClick={() => setModalAberto('addProduto')}
          className="bg-green-500 text-white px-6 py-2 rounded-lg flex items-center gap-2 hover:bg-green-600"
        >
          <Plus size={20} />
          Adicionar
        </button>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold">Nome</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Categoria</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Preço</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Estoque</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Ações</th>
            </tr>
          </thead>
          <tbody>
            {produtosFiltrados.map(produto => (
              <tr key={produto.id} className="border-t hover:bg-gray-50">
                <td className="px-6 py-4">{produto.nome}</td>
                <td className="px-6 py-4">
                  <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                    {produto.categoria}
                  </span>
                </td>
                <td className="px-6 py-4">R$ {produto.preco.toFixed(2)}</td>
                <td className="px-6 py-4">
                  <span className={`font-semibold ${produto.estoque < 10 ? 'text-red-600' : 'text-green-600'}`}>
                    {produto.estoque} un
                  </span>
                </td>
                <td className="px-6 py-4">
                  <button className="text-blue-600 hover:underline mr-3">Editar</button>
                  <button className="text-red-600 hover:underline">Excluir</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  // Tela de Vender
  const Vender = () => (
    <div className="p-8">
      <h2 className="text-3xl font-bold mb-6 text-gray-900">💰 Registrar Venda</h2>
      
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-xl font-semibold mb-4">Selecionar Produtos</h3>
          
          <input
            type="text"
            placeholder="Buscar produto..."
            className="w-full mb-4 px-4 py-2 border rounded-lg"
          />

          <div className="space-y-2 max-h-96 overflow-y-auto">
            {produtos.map(produto => (
              <div key={produto.id} className="flex items-center justify-between p-3 border rounded hover:bg-gray-50">
                <div>
                  <p className="font-semibold">{produto.nome}</p>
                  <p className="text-sm text-gray-600">R$ {produto.preco.toFixed(2)} • Estoque: {produto.estoque}</p>
                </div>
                <button
                  onClick={() => setCarrinho([...carrinho, produto])}
                  className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
                >
                  <Plus size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-xl font-semibold mb-4">Carrinho</h3>
          
          {carrinho.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Carrinho vazio</p>
          ) : (
            <>
              <div className="space-y-2 mb-4 max-h-60 overflow-y-auto">
                {carrinho.map((item, index) => (
                  <div key={index} className="flex justify-between items-center p-3 border rounded">
                    <span>{item.nome}</span>
                    <div className="flex items-center gap-3">
                      <span>R$ {item.preco.toFixed(2)}</span>
                      <button
                        onClick={() => setCarrinho(carrinho.filter((_, i) => i !== index))}
                        className="text-red-600 hover:underline text-sm"
                      >
                        Remover
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between mb-4">
                  <span className="text-xl font-bold">Total:</span>
                  <span className="text-xl font-bold text-green-600">
                    R$ {carrinho.reduce((acc, item) => acc + item.preco, 0).toFixed(2)}
                  </span>
                </div>

                <div className="space-y-3">
                  <select className="w-full px-4 py-2 border rounded-lg">
                    <option>Selecionar Cliente (opcional)</option>
                    {clientes.map(c => (
                      <option key={c.id}>{c.nome}</option>
                    ))}
                  </select>

                  <div className="flex gap-3">
                    <button className="flex-1 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600 font-semibold">
                      Venda à Vista
                    </button>
                    <button
                      onClick={() => setModalAberto('vendaFiado')}
                      className="flex-1 bg-blue-500 text-white py-3 rounded-lg hover:bg-blue-600 font-semibold"
                    >
                      Venda Fiado
                    </button>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );

  // Tela de Clientes
  const Clientes = () => (
    <div className="p-8">
      <h2 className="text-3xl font-bold mb-6 text-gray-900">👤 Gestão de Clientes</h2>
      
      <button
        onClick={() => setModalAberto('addCliente')}
        className="bg-green-500 text-white px-6 py-2 rounded-lg flex items-center gap-2 hover:bg-green-600 mb-6"
      >
        <Plus size={20} />
        Novo Cliente
      </button>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold">Nome</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Telefone</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Dívida</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Ações</th>
            </tr>
          </thead>
          <tbody>
            {clientes.map(cliente => (
              <tr key={cliente.id} className="border-t hover:bg-gray-50">
                <td className="px-6 py-4 font-semibold">{cliente.nome}</td>
                <td className="px-6 py-4">{cliente.telefone}</td>
                <td className="px-6 py-4">
                  <span className={`font-semibold ${cliente.divida > 0 ? 'text-red-600' : 'text-green-600'}`}>
                    R$ {cliente.divida.toFixed(2)}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <button className="text-blue-600 hover:underline mr-3">Ver Histórico</button>
                  <button className="text-blue-600 hover:underline">Editar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  // Tela de Dívidas
  const Dividas = () => (
    <div className="p-8">
      <h2 className="text-3xl font-bold mb-6 text-gray-900">💳 Controle de Dívidas</h2>
      
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-semibold">Cliente</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Total</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Pago</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Restante</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Juros</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Vencimento</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Ações</th>
            </tr>
          </thead>
          <tbody>
            {dividas.map(divida => {
              const restante = divida.valor - divida.pago;
              const vencido = new Date(divida.vencimento) < new Date();
              
              return (
                <tr key={divida.id} className="border-t hover:bg-gray-50">
                  <td className="px-6 py-4 font-semibold">{divida.cliente}</td>
                  <td className="px-6 py-4">R$ {divida.valor.toFixed(2)}</td>
                  <td className="px-6 py-4 text-green-600">R$ {divida.pago.toFixed(2)}</td>
                  <td className="px-6 py-4 text-red-600 font-semibold">R$ {restante.toFixed(2)}</td>
                  <td className="px-6 py-4">{divida.juros}%</td>
                  <td className="px-6 py-4">
                    <span className={vencido ? 'text-red-600 font-semibold' : ''}>
                      {divida.vencimento}
                      {vencido && ' ⚠️'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => setModalAberto('pagamento')}
                      className="bg-green-500 text-white px-4 py-1 rounded hover:bg-green-600"
                    >
                      Receber
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );

  // Modal de Venda Fiado
  const ModalVendaFiado = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 max-w-md w-full">
        <h3 className="text-2xl font-bold mb-6">Configurar Venda Fiado</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-semibold mb-2">Cliente</label>
            <select className="w-full px-4 py-2 border rounded-lg">
              {clientes.map(c => (
                <option key={c.id}>{c.nome}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2">Taxa de Juros (%)</label>
            <input type="number" defaultValue="5" className="w-full px-4 py-2 border rounded-lg" />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2">Dias para Vencimento</label>
            <input type="number" defaultValue="30" className="w-full px-4 py-2 border rounded-lg" />
          </div>

          <div className="bg-gray-100 p-4 rounded">
            <p className="text-sm text-gray-600">Total Original:</p>
            <p className="text-xl font-bold">R$ {carrinho.reduce((acc, item) => acc + item.preco, 0).toFixed(2)}</p>
            <p className="text-sm text-gray-600 mt-2">Total com Juros (5%):</p>
            <p className="text-2xl font-bold text-green-600">
              R$ {(carrinho.reduce((acc, item) => acc + item.preco, 0) * 1.05).toFixed(2)}
            </p>
          </div>

          <div className="flex gap-3 mt-6">
            <button
              onClick={() => setModalAberto(null)}
              className="flex-1 bg-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-400"
            >
              Cancelar
            </button>
            <button
              onClick={() => {
                alert('Venda fiado registrada com sucesso!');
                setModalAberto(null);
                setCarrinho([]);
              }}
              className="flex-1 bg-green-500 text-white py-3 rounded-lg hover:bg-green-600"
            >
              Confirmar
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-100">
      <MenuLateral />
      
      <div className="flex-1 overflow-y-auto">
        {telaAtiva === 'dashboard' && <Dashboard />}
        {telaAtiva === 'produtos' && <Produtos />}
        {telaAtiva === 'vender' && <Vender />}
        {telaAtiva === 'clientes' && <Clientes />}
        {telaAtiva === 'dividas' && <Dividas />}
      </div>

      {modalAberto === 'vendaFiado' && <ModalVendaFiado />}
    </div>
  );
};

export default SistemaVendas;